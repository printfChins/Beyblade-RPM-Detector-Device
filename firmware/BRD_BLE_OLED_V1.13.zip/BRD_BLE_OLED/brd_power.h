/* 檔案位置: BRD_BLE_OLED/brd_power.h
   [V1.10 新增] 待機關閉 OLED 與 GPIO1 HIGH 深度睡眠喚醒。 */
#ifndef BRD_POWER_H
#define BRD_POWER_H

void brd_power_begin(void);
void brd_power_update(void);

#endif
