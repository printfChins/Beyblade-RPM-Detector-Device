/* 檔案位置: BRD_BLE_OLED/brd_power.cpp
   [V1.10 移植] 取自 BLE_RPM V1.9 的 30 秒 OLED OFF / 5 分鐘 Deep-sleep。
   [V1.10 修改] 改由目前主 loop 操作 OLED，避免舊版跨 Task I2C 存取。
   [V1.10 刪減] 舊版 brd_context / OLED Task / Serial / Light-sleep 相依。 */
#include <Arduino.h>
#include <esp_idf_version.h>
#include <esp_sleep.h>
#include <driver/gpio.h>

#include "brd_battery.h"
#include "brd_ble.h"
#include "brd_config.h"
#include "brd_io.h"
#include "brd_measurement.h"
#include "brd_oled.h"
#include "brd_power.h"
#include "brd_record.h"

static bool g_idle_active = false;
static uint32_t g_idle_start_ms = 0UL;

static bool power_idle_allowed(void) {
    const brd_telemetry_t state = brd_measurement_get_telemetry();
    const brd_ble_diagnostics_t ble = brd_ble_get_diagnostics();
    const brd_record_info_t record = brd_record_get_info();
    /* [V1.11 修改] 只要曲線尚保存在 RAM 就禁止 Deep-sleep，避免 TIMEOUT 後資料遺失。 */
    const bool result_pending = record.ready;
    return brd_battery_measurement_allowed() && state.state == BRD_STATE_WAIT_LOAD &&
           !state.loaded && !state.active && !ble.connected &&
           !brd_io_is_charging() && !result_pending;
}

void brd_power_begin(void) {
    g_idle_active = false;
    g_idle_start_ms = millis();
    brd_oled_set_idle_off(false);
}

void brd_power_update(void) {
    if (!power_idle_allowed()) {
        g_idle_active = false;
        brd_oled_set_idle_off(false);
        return;
    }
    uint32_t now_ms = millis();
    if (!g_idle_active) {
        g_idle_active = true;
        g_idle_start_ms = now_ms;
        return;
    }
    uint32_t elapsed_ms = (uint32_t)(now_ms - g_idle_start_ms);
    if (elapsed_ms >= LOW_POWER_OLED_OFF_TIMEOUT_MS) {
        brd_oled_set_idle_off(true);
    }
    if (elapsed_ms < LOW_POWER_DEEP_SLEEP_TIMEOUT_MS) {
        return;
    }
    // [V1.10 新增] 活動時 GPIO1 無內部上下拉；Deep-sleep 喚醒電阻
    // 另受 Arduino Core 的 ESP_SLEEP_GPIO_ENABLE_INTERNAL_RESISTORS 設定影響。
    // 先設定喚醒來源；設定失敗時保持運作，每次待機重新計時。
    (void)esp_sleep_disable_wakeup_source(ESP_SLEEP_WAKEUP_ALL);
#if ESP_IDF_VERSION_MAJOR >= 6
    esp_err_t result = esp_sleep_enable_gpio_wakeup_on_hp_periph_powerdown(
        1ULL << LOW_POWER_WAKE_GPIO, ESP_GPIO_WAKEUP_GPIO_HIGH);
#else
    esp_err_t result = esp_deep_sleep_enable_gpio_wakeup(
        1ULL << LOW_POWER_WAKE_GPIO, ESP_GPIO_WAKEUP_GPIO_HIGH);
#endif
    if (result != ESP_OK) {
        g_idle_active = false;
        brd_oled_set_idle_off(false);
        return;
    }
    // [V1.10 新增] 檢查休眠門檻與關屏狀態後才停 BLE；意外裝載須恢復 BLE。
    if (!power_idle_allowed() || !brd_oled_idle_is_off()) {
        (void)esp_sleep_disable_wakeup_source(ESP_SLEEP_WAKEUP_ALL);
        return;
    }
    brd_ble_set_enabled(false);
    // [V1.10 新增] BLE 釋放失敗或電池在關閉期間變為故障時放棄睡眠。
    brd_battery_update();
    if (!brd_ble_stack_stopped() || !brd_battery_measurement_allowed()) {
        (void)esp_sleep_disable_wakeup_source(ESP_SLEEP_WAKEUP_ALL);
        brd_oled_set_idle_off(false);
        g_idle_active = false;
        return;
    }
    if (gpio_get_level((gpio_num_t)LOAD_IR_GPIO) == LOAD_ACTIVE_LEVEL || brd_io_is_charging()) {
        (void)esp_sleep_disable_wakeup_source(ESP_SLEEP_WAKEUP_ALL);
        brd_ble_set_enabled(true);
        brd_oled_set_idle_off(false);
        g_idle_active = false;
        return;
    }
    // [V1.10 移植] GPIO8 維持原專案固定熄燈狀態；HIGH 裝載喚醒後執行 setup()。
    esp_deep_sleep_start();
}
