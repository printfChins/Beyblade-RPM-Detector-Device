# BRD_BLE_OLED V1.13 時間與 Timeout 檢查

## RPM Dual-edge Timing

V1.13 使用 `CHANGE` 捕捉 RPM Rising / Falling。

```text
Falling RPM = 60000000 / (F[n] - F[n-1])
Rising RPM  = 60000000 / (R[n] - R[n-1])
```

兩者都使用完整 360 度週期；不使用相鄰 edge 的半圈 period 直接換算。

`rpm_dual_edge_micros_wrap` 驗證其中一條同極性完整週期跨越 `micros()` 32-bit 回繞時，unsigned subtraction 仍得到正確週期。

## BLE Data / Curve

| 項目 | 值 | 行為 |
| --- | ---: | --- |
| B1 LIVE | 200 ms | 僅 SPINNING / telemetry.active 時 Notify |
| Packet spacing | 8 ms | 每輪至多一個 Data Notify |
| Subscribe settle | 100 ms | 0002 / 0006 訂閱後等待 |
| Curve SEND timeout | 5000 ms | START/DATA/END 尚未送完即 TX_TIMEOUT |
| ACK retry | 1000 ms | WAIT_ACK 每秒完整重送 |
| ACK timeout | 5000 ms | Retry 不重置窗口 |
| A4 STATUS timeout | 2000 ms | pending 必定解除並執行後續 action |

## State Indication

| 項目 | 值 | 行為 |
| --- | ---: | --- |
| State retry gate | 100 ms | Indication 無法排入 stack 時限制重試頻率 |
| State confirmation timeout | 2000 ms | 無法取得 ATT Confirmation 時主動 disconnect |

State pending 只有在 NimBLE `onStatus(..., BLE_HS_EDONE)` 收到 Confirmation 後才視為完成。所有 timeout 比較均使用 unsigned subtraction，可跨 `millis()` 32-bit 回繞。

## Measurement

發射後結束門檻：

```text
ceil(MAX_RPM × 35 / 100)
```

單筆有效 `current_rpm <= threshold` 時結束。MAX 本身使用原始同極性完整一圈 RPM，不做平滑。

## Low power

- 30 秒 OLED OFF。
- 5 分鐘 Deep-sleep。
- `record.ready` 為 true 時 idle 不成立。
- WAIT_LOAD / READY / RESULT idle 不週期傳 B1。

## Boot

- `ESP_RST_POWERON`：播放版本畫面 1500 ms。
- `ESP_RST_DEEPSLEEP`：跳過版本畫面。
- SW/WDT/其他 reset：跳過版本畫面。
