# BRD Reliable BLE Protocol V2

對應韌體：`BRD_BLE_OLED V1.13`

V2 將 BLE 分成三個用途：

1. **State**：`0006`，READ + INDICATE，只有狀態/旗標改變或新訂閱時傳送 `0x81`。
2. **Live / Result Data**：`0002`，NOTIFY；`B1` 只在 SPINNING 時每 200 ms 傳送，`B2` 為 Launch event。
3. **Reliable Curve**：`0002 + 0003`，維持 A1/A2/A3/A4 與 C1/C2/C3/C4、Session、Packet Index、CRC32、ACK/重傳/Abort。

## GATT

Service UUID：

```text
7f510001-1b15-4d5f-9f4d-9b3c7a1d9a10
```

| 功能 | UUID | Properties |
| --- | --- | --- |
| Data | `7f510002-1b15-4d5f-9f4d-9b3c7a1d9a10` | READ, NOTIFY |
| Control | `7f510003-1b15-4d5f-9f4d-9b3c7a1d9a10` | WRITE |
| Firmware Revision | `7f510004-1b15-4d5f-9f4d-9b3c7a1d9a10` | READ |
| Diagnostic | `7f510005-1b15-4d5f-9f4d-9b3c7a1d9a10` | READ |
| State | `7f510006-1b15-4d5f-9f4d-9b3c7a1d9a10` | READ, INDICATE |

裝置名稱：`BRD_XXXX`，`XXXX` 為 MCU ID 後 4 碼 HEX。

MTU 以 23 相容設計，Data Notification 最大 20 bytes。

所有 `uint16_t` / `uint32_t` 為 Little-endian。

---

## 0x81 STATE SNAPSHOT / EVENT

Characteristic：`0006 State`

方向：Device -> App

傳輸方式：**Indication**。

長度：5 bytes。

| Offset | Size | 欄位 |
| ---: | ---: | --- |
| 0 | 1 | `0x81` |
| 1 | 1 | state |
| 2 | 1 | flags |
| 3 | 2 | state_seq |

### state

| Value | 意義 |
| ---: | --- |
| `0` | WAIT_LOAD |
| `1` | LOADED_READY |
| `2` | SPINNING_LOADED |
| `3` | SPINNING_LAUNCHED |
| `4` | RESULT_PENDING |

### flags

- bit0：Loaded
- bit1：Active / Spinning
- bit2：Launch Valid
- bit3：Result Pending
- bit4：Charging
- bit5：WAIT_ACK
- bit6：Reserved
- bit7：Reserved

### state_seq

`uint16_t`，狀態或 flags 真正變化時 `+1`，`0xFFFF -> 0x0000` 允許自然回繞。

**新連線 / 新訂閱 Snapshot 不增加 state_seq**，App 可用序號判斷連線期間是否跨過狀態事件。

### 傳送條件

不週期送 State。只有：

- state 改變；
- flags 改變；
- App 新訂閱 `0006` Indication；
- App READ `0006` 取得當下 Snapshot。

### Indication 確認

韌體不以 `indicate()` 回傳 true 視為 App 已收到；必須等 NimBLE `onStatus(..., BLE_HS_EDONE)` 才完成這筆 State。

如果：

- indication 無法送入 BLE stack；或
- indication 已送入 stack，但 2 秒內沒有 ATT Confirmation；

則韌體會在 `BLE_STATE_INDICATE_TIMEOUT_MS = 2000 ms` 後主動斷線。App 重連並再次訂閱後會收到最新 Snapshot，避免永久停留舊狀態。

送入 stack 失敗時，每 `BLE_STATE_INDICATE_RETRY_MS = 100 ms` 重試；已送入 stack 等待 Confirmation 時不重複送同一筆。

---

## B1 LIVE RPM

Characteristic：`0002 Data`

方向：Device -> App

傳輸方式：Notification。

長度：13 bytes。

**V1.12 起只有 `telemetry.active == true`（SPINNING）時，每 200 ms 傳送。WAIT_LOAD / READY / RESULT 靜止期間不再週期送 B1。**

| Offset | Size | 欄位 |
| ---: | ---: | --- |
| 0 | 1 | `0xB1` |
| 1 | 1 | state |
| 2 | 1 | flags |
| 3 | 2 | current RPM |
| 5 | 2 | max RPM |
| 7 | 2 | launch RPM |
| 9 | 2 | curve duration ms |
| 11 | 2 | curve sample count |

B1 為即時 UI 資料，允許個別 Notification 遺失；重要狀態由 `0x81 Indication` 負責。

---

## B2 LAUNCH

Characteristic：`0002 Data`

方向：Device -> App，Notification。

長度：9 bytes。

| Offset | Size | 欄位 |
| ---: | ---: | --- |
| 0 | 1 | `0xB2` |
| 1 | 2 | launch RPM |
| 3 | 2 | max at launch |
| 5 | 2 | launch time ms |
| 7 | 2 | launch sample index |

---

## A1 CURVE START

Characteristic：`0002 Data`

方向：Device -> App，Notification。

長度：20 bytes。

| Offset | Size | 欄位 |
| ---: | ---: | --- |
| 0 | 1 | `0xA1` |
| 1 | 2 | sample count |
| 3 | 2 | sample interval，event curve 固定 `0` |
| 5 | 2 | duration ms |
| 7 | 2 | max RPM |
| 9 | 2 | launch RPM |
| 11 | 2 | launch time ms |
| 13 | 2 | launch sample index |
| 15 | 1 | flags |
| 16 | 2 | max RPM time ms |
| 18 | 2 | session |

A1 flags：

- bit0：Launch Valid
- bit1：Curve Complete；未 truncated 時為 1
- bit2：Event Curve Format；固定為 1

---

## A2 CURVE DATA

Characteristic：`0002 Data`

方向：Device -> App，Notification。

每包最多 4 samples。

```text
Byte 0      0xA2
Byte 1      N (1..4)
Byte 2..3   Packet Index
Byte 4..    Samples
```

每個 Sample 4 bytes：

```text
uint16 Time_ms
uint16 RPM
```

曲線第一筆固定為：

```text
Packet 0 / Sample 0
Time_ms = 0
RPM     = 0
```

之後為每筆有效完整一圈 RPM sample。

V1.13 的 RPM ISR 使用 `CHANGE` 同時捕捉 Rising / Falling，但不直接使用半圈 period：

```text
Falling sample = 60000000 / (F[n] - F[n-1])
Rising sample  = 60000000 / (R[n] - R[n-1])
```

兩種 sample 都代表完整 360 度週期，兩個量測窗口約相差 180 度，因此穩定後約每半圈可新增一筆 Curve sample。A2 的 `Time_ms + RPM` 格式不變。

Packet Index 從 0 起算：

```text
packet_count = ceil(sample_count / 4)
```

---

## A3 CURVE END

Characteristic：`0002 Data`

方向：Device -> App，Notification。

長度：11 bytes。

| Offset | Size | 欄位 |
| ---: | ---: | --- |
| 0 | 1 | `0xA3` |
| 1 | 2 | session |
| 3 | 2 | packet count |
| 5 | 2 | sample count |
| 7 | 4 | CRC32 |

CRC32：CRC-32/ISO-HDLC。

輸入為每個 Sample 的 Little-endian 4 bytes：

```text
Time_L Time_H RPM_L RPM_H
```

包含第一筆 `0 ms / 0 RPM`。

---

## A4 STATUS

Characteristic：`0002 Data`

方向：Device -> App，Notification。

長度：6 bytes。

| Offset | Size | 欄位 |
| ---: | ---: | --- |
| 0 | 1 | `0xA4` |
| 1 | 2 | session |
| 3 | 1 | status |
| 4 | 2 | detail |

status：

| Code | 意義 |
| --- | --- |
| `0x00` | ACK accepted |
| `0x01` | selective retransmission accepted |
| `0x02` | full retransmission accepted |
| `0x03` | abort accepted |
| `0x80` | session mismatch |
| `0x81` | packet index invalid |
| `0x82` | command format invalid |
| `0x83` | sample count mismatch |
| `0x84` | CRC mismatch |
| `0x85` | no result |
| `0x86` | ACK window invalid / expired |

注意：A4 內的 `status=0x81` 與 State packet 的 `type=0x81` 位於不同 Characteristic/欄位，沒有封包衝突。

A4 Notification 若連續失敗超過 2 秒，韌體解除 pending 並執行該命令既定後續動作，不永久阻塞 Command path。

---

## C1 ACK

Characteristic：`0003 Control`

方向：App -> Device，WRITE。

9 bytes：

```text
0xC1
uint16 session
uint16 sample_count
uint32 crc32
```

只有以下全部成立才接受：

- session 正確；
- sample_count 正確；
- CRC32 正確；
- TX state = WAIT_ACK；
- 尚未超過 5 秒 ACK window。

Duplicate C1 為 idempotent：若同一筆結果已成功 ACK，只重回 A4，不會清除後續新 Session。

---

## C2 SELECTIVE RETRANSMISSION

```text
0xC2
uint16 session
uint8 count          // 0..8
uint16 packet_index[count]
```

Packet Index 必須 `< A3 packet_count`，否則回 A4 `0x81`。

`count = 0`：只重送 A3 END。

---

## C3 FULL RETRANSMISSION

3 bytes：

```text
0xC3
uint16 session
```

`session = 0xFFFF` 代表要求目前 RAM 中保存的 Result 完整重傳。

成功後回 A4 `0x02`，再重送 A1/A2/A3。

---

## C4 ABORT

3 bytes：

```text
0xC4
uint16 session
```

成功後回 A4 `0x03`，清除該筆 RAM Curve；OLED MAX 顯示不受影響。

---

## Reliable Curve Timeout

```text
BLE_SEND_TIMEOUT_MS   = 5000 ms
BLE_ACK_TIMEOUT_MS    = 5000 ms
BLE_ACK_RETRY_MS      = 1000 ms
BLE_STATUS_TIMEOUT_MS = 2000 ms
```

流程：

```text
START / DATA / END 尚未成功 Notify
  -> 5 秒 -> TX_TIMEOUT

A3 成功
  -> WAIT_ACK
  -> 每 1 秒完整重傳
  -> 原 ACK window 不重置
  -> 5 秒 -> TX_TIMEOUT

A4 Notify 失敗
  -> 最多 2 秒
  -> 解除 pending 並執行命令後續動作
```

---

## Disconnect / Reconnect

BLE 斷線不清除尚未 ACK 的 Curve。

重新連線後 App 應：

1. Subscribe `0002` Notification；
2. Subscribe `0006` Indication；
3. 收到/READ `0x81` Current State Snapshot；
4. 若 Device RAM 有 Result，韌體從 A1 開始重新傳送。

---

## Firmware Revision

Characteristic：`0004`

Property：READ。

V1.13：

```text
V1.13
```

---

## Diagnostic

Characteristic：`0005`

Property：READ。

長度：20 bytes。

| Offset | Size | 欄位 |
| ---: | ---: | --- |
| 0 | 1 | Protocol Version = `2` |
| 1 | 1 | TX State |
| 2 | 1 | flags |
| 3 | 1 | Reliable Mode = `1` |
| 4 | 2 | Current Result Session |
| 6 | 2 | Sample Count |
| 8 | 4 | CRC32 |
| 12 | 2 | Duration ms |
| 14 | 2 | Command Errors |
| 16 | 2 | Notify Failures |
| 18 | 2 | ACK Timeouts |

TX State：

```text
0 IDLE
1 START
2 DATA
3 END
4 WAIT_ACK
5 DONE
6 TIMEOUT
```

Diagnostic flags：

- bit0：Result Ready
- bit1：Curve Truncated

---

## App 建議連線順序

```text
Scan BRD_XXXX
 -> Connect
 -> Discover 0001 Service
 -> Subscribe 0002 Notification
 -> Subscribe 0006 Indication
 -> Read 0004 Firmware Version
 -> Optionally Read 0005 Diagnostic
 -> Read/Receive 0006 Current State Snapshot
```

`0006` 在 React Native / NimBLE Client 端必須使用 **Indication subscription**，不是 Notification subscription。

狀態 UI 以 `0x81` 為準；B1 僅作 SPINNING 即時 RPM。

---

## Curve Stop Condition

V1.12 沿用 V1.11：

```text
threshold = ceil(MAX_RPM * 35 / 100)
current_rpm <= threshold -> finish
```

另保留無脈衝 timeout 備援。
