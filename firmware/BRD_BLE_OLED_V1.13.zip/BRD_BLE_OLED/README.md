# BRD_BLE_OLED V1.13

ESP32-C3 Beyblade RPM Detector BLE + OLED 韌體。

V1.13 沿用 V1.12 的 BRD Reliable BLE Protocol V2，BLE 封包格式不變。本版重點是 RPM 量測解析度：`IR_RPM` 由單一 FALLING 改為 `CHANGE`，同時捕捉 Rising / Falling；兩種極性各自與自己的上一個同極性 edge 比較，因此每筆 RPM 仍是完整 360 度週期，不直接以半圈時間換算。兩組完整一圈量測窗口相差約 180 度，可讓 MAX / Launch RPM 約每半圈更新一次，同時避免白黑占空比或施密特遲滯造成半圈假高 RPM。

## 專案位置

```text
Beyblade-RPM-Detector-Device/
├─ firmware/
│  └─ BRD_BLE_OLED/
│     ├─ BRD_BLE_OLED.ino
│     ├─ brd_config.h
│     ├─ brd_ble.cpp
│     ├─ brd_ble.h
│     ├─ brd_record.cpp
│     ├─ brd_record.h
│     ├─ brd_measurement.cpp
│     ├─ brd_measurement.h
│     ├─ brd_battery.cpp
│     ├─ brd_battery.h
│     ├─ brd_io.cpp
│     ├─ brd_io.h
│     ├─ brd_oled.cpp
│     ├─ brd_oled.h
│     ├─ brd_power.cpp
│     ├─ brd_power.h
│     ├─ BLE_PROTOCOL.md
│     ├─ BLE_API_V1.13.txt
│     ├─ CHANGELOG.md
│     ├─ VALIDATION.md
│     └─ TIME_REVIEW.md
└─ verification/
   ├─ run_host_tests.py
   ├─ host/
   └─ time_review/
      └─ run_time_review.py
```

Arduino sketch 資料夾名稱維持 `BRD_BLE_OLED`，與 `BRD_BLE_OLED.ino` 同名。

## V1.13 主要修改

- [修改] `PROJECT_VERSION` 更新為 `V1.13`。
- [修改] `RPM_IR_TRIGGER_EDGE`：`FALLING` -> `CHANGE`。
- [新增] RPM ISR 同時保存 edge timestamp 與 edge level。
- [新增] Rising 與 Falling 各自保存上一個同極性 timestamp。
- [修改] Falling RPM = `60000000 / (F[n] - F[n-1])`。
- [修改] Rising RPM = `60000000 / (R[n] - R[n-1])`。
- [保留] 每筆 RPM 都是完整 360 度週期；不使用 `30000000 / half_period`。
- [保留] MAX RPM 不做平均、IIR、移動平均或候選峰值濾波。
- [改善] 兩套完整一圈窗口相差約 180 度，穩定後約每半圈更新一次 RPM，提升 MAX / Launch RPM 的時間解析度。
- [保留] Curve 第 0 筆 `0 ms / 0 RPM`、35% 停止門檻與所有 Reliable BLE 機制。
- [保留] BLE Protocol Version = 2，GATT / A1~A4 / B1~B2 / C1~C4 封包格式不變。

## RPM 量測原理

編碼盤為半白、半黑。硬體事件順序理想上為：

```text
F0 -------- R0 -------- F1 -------- R1 -------- F2
     約半圈      約半圈      約半圈      約半圈
```

韌體不直接使用相鄰 edge 的半圈時間。

```text
Falling channel: F0 ---------------- F1 -> RPM_F
Rising channel :      R0 ---------------- R1 -> RPM_R
```

公式：

```text
RPM_F = 60000000 / (F[n] - F[n-1])
RPM_R = 60000000 / (R[n] - R[n-1])
```

例如實際光學切換造成半圈為 1200 us / 1300 us，兩個完整一圈仍各為 2500 us，因此兩條通道皆得到 24000 RPM，不會把較短的 1200 us 半圈錯算成 25000 RPM。

Launch RPM 仍在 LOAD HIGH -> LOW 原始時間點鎖定當時最近、已完成的有效 RPM；因 RPM 更新間隔由一圈縮短至約半圈，Launch snapshot 的時間解析度同步提高。

## BLE GATT

Service：

```text
7f510001-1b15-4d5f-9f4d-9b3c7a1d9a10
```

| Characteristic | UUID 尾碼 | 權限 | 用途 |
| --- | --- | --- | --- |
| Data | `0002` | READ / NOTIFY | B1/B2/A1/A2/A3/A4 |
| Control | `0003` | WRITE | C1/C2/C3/C4 |
| Firmware Revision | `0004` | READ | ASCII `V1.13` |
| Diagnostic | `0005` | READ | 20-byte 診斷快照，Protocol Version = 2 |
| State | `0006` | READ / INDICATE | `0x81` State Snapshot/Event |

App 必須分別訂閱：

```text
0002 -> Notification
0006 -> Indication
```

完整封包格式請見 `BLE_PROTOCOL.md` 或 `BLE_API_V1.13.txt`。

## Curve

第一筆固定：

```text
Sample 0
Time = 0 ms
RPM  = 0
```

之後每一筆都是有效的完整一圈 RPM sample。V1.13 在穩定雙邊沿狀態下，Rising / Falling 兩條 360 度窗口交錯，因此 Curve 最多可約每半圈新增一筆，但 RPM 值本身不是半圈換算。

A3 CRC32 規則及封包格式均未變。

## 停止條件

```text
threshold = ceil(MAX_RPM × 35 / 100)
current_rpm <= threshold -> finish
```

仍保留無脈衝 timeout 備援與 HOLD / MAX 顯示邏輯。

## 低功耗

- WAIT LOAD、未裝載、未連線、未充電、沒有 RAM 結果時開始 idle timer。
- 30 秒關閉 OLED。
- 5 分鐘停止 BLE，確認 NimBLE stack 已停止後進 Deep-sleep。
- GPIO1 / LOAD HIGH 喚醒。
- `record.ready == true` 時禁止 Deep-sleep。
- Deep-sleep 喚醒不播放 Boot Logo。

## 建置條件

- ESP32-C3
- Arduino-ESP32 / ESP-IDF 5.3 以上
- NimBLE-Arduino 2.5.1
- CPU 80 MHz
- Flash 4 MB

## 驗證

```bash
python3 verification/run_host_tests.py
python3 verification/time_review/run_time_review.py --project-root .
```

目前 V1.13 通過 79 項主機案例、13 項時間／rollover 專項，以及 8 個主程式 / C++ 檔獨立 C++17 語法檢查。主機測試不等同 ESP32-C3 實機光學、RF、ATT Confirmation、功耗與喚醒驗證，詳見 `VALIDATION.md`。
