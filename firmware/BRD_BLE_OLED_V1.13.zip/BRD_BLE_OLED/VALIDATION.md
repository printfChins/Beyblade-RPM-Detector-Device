# BRD_BLE_OLED V1.13 驗證紀錄

日期：2026-09-14

## 已完成

執行：

```bash
python3 verification/run_host_tests.py
```

結果：

```text
79 cases passed; hardware interfaces are mocked.
```

並對 8 個主程式 / C++ 檔做獨立 C++17 語法檢查：

- `BRD_BLE_OLED.ino`
- `brd_battery.cpp`
- `brd_ble.cpp`
- `brd_io.cpp`
- `brd_measurement.cpp`
- `brd_oled.cpp`
- `brd_power.cpp`
- `brd_record.cpp`

參數包含：

```text
-Wall -Wextra -Werror -Wshadow -pedantic
```

主機測試同時使用 AddressSanitizer / UndefinedBehaviorSanitizer。

另執行：

```bash
python3 verification/time_review/run_time_review.py --project-root .
```

結果：

```text
Complete: 13 V1.13 time/rollover checks passed; firmware unchanged.
```

## V1.13 新增驗證

| 測試 | 驗證內容 |
| --- | --- |
| `rpm_dual_edge_change_trigger` | RPM 中斷設定必須為 `CHANGE` |
| `rpm_dual_edge_full_revolution` | 半圈 1200/1300 us 不對稱時，Rising/Falling 都使用 2500 us 完整一圈，結果固定 24000 RPM |
| `rpm_dual_edge_half_rev_update` | Falling 與 Rising 兩個完整一圈窗口交錯，約半圈後可更新下一筆 RPM / MAX |
| `rpm_dual_edge_micros_wrap` | 同極性完整週期跨 `micros()` 32-bit 回繞仍正確 |
| `launch_uses_latest_dual_edge_rpm` | LOAD 發射邊沿鎖定最近、已完成的雙邊沿完整一圈 RPM；測試 24000 RPM |
| `normal_30k_dual_edge` | 30000 RPM、每 1000 us 一個交替 edge 時，Rising/Falling 完整一圈皆維持 30000 RPM 且 queue 無 overflow |

## 持續回歸

仍涵蓋：

- LOAD 事件時間排序與去抖。
- RPM queue overflow / gap。
- MAX 35% 結束條件。
- Raw MAX / Launch snapshot。
- Curve 0/0 起點、CRC、micros wrap。
- State Indication / ATT Confirmation / state_seq。
- Reliable A1~A4 / C1~C4、ACK、重傳、Abort、Disconnect recovery。
- OLED HOLD / Boot、ADC、低電與 Deep-sleep。

## 尚未完成

以下需要 ESP32-C3 實機驗證：

- ITR8307 + SN74LVC2G14 實際 Rising / Falling 光學切換位置與占空比。
- 最高實際 RPM 下 CHANGE 中斷頻率與 ISR queue 餘量。
- 與原 FALLING-only 版本同一組發射的 MAX / Launch RPM 重複性比較。
- NimBLE 真實 RF 丟包／連線中斷壓力測試。
- iOS / Android `0006 Indication` ATT Confirmation 互通。
- 實際平均電流、OLED OFF、Deep-sleep 與 GPIO1 喚醒。
- ESP32-C3 Arduino 目標完整建置與燒錄。
