"""[V0.12 新增] 執行原始模組的主機邏輯回歸；不代表 ESP32-C3 實機驗證。"""
from pathlib import Path
import argparse
import os
import subprocess
import tempfile

CASES = """threshold20 one_dropped_edge spike_policy_unchanged load_backlog
load_short_bounce load_exact_debounce load_rpm_chronology timeout_chronology
unload_before_first_rpm load_overflow rpm_overflow hold_unlock_generation
micros_wrap millis_wrap_hold no_rpm_timeout normal_30k adc_single_conversion
adc_error_keeps_value adc_stale adc_stale_latch_wrap oled_boot_version adc_boot_error adc_config_retry
adc_calibration_retry adc_invalid_data valid_zero_is_low exact_five
recovery_duration recovery_error_break recovery_low_break recovery_gap
recovery_millis_wrap reboot_policy_unchanged main_adc_fault_resume main_low_restart
 oled_adc_boot_recover oled_retry_hold gpio_pulls""".split()

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    with tempfile.TemporaryDirectory(prefix='brd_v012_') as work:
        destination = args.output.resolve() if args.output else Path(work)
        destination.mkdir(parents=True, exist_ok=True)
        binary = Path(work) / 'test_v012'
        command = [os.environ.get('CXX', 'g++'), '-std=c++17', '-Wall', '-Wextra', '-Werror',
                   '-Wshadow', '-pedantic', '-fsanitize=address,undefined', '-fno-omit-frame-pointer',
                   '-I', str(root / 'host'), str(root / 'host/test_v012.cpp'), '-o', str(binary)]
        subprocess.run(command, check=True)
        environment = dict(os.environ, ASAN_OPTIONS='detect_leaks=0')
        for case in CASES:
            subprocess.run([str(binary), case], check=True, cwd=destination, env=environment)
        print(f'{len(CASES)} cases passed; hardware interfaces are mocked.')

if __name__ == '__main__':
    main()
