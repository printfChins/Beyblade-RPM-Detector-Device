#pragma once
#include <stdexcept>
extern int test_restarts;
[[noreturn]] inline void esp_restart() { test_restarts++; throw std::runtime_error("mock_reset"); }
