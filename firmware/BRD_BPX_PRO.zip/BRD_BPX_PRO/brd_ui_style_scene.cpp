/*
 * File: BRD_BPX_PRO/brd_ui_style_scene.cpp
 * [修改] 只保留使用者指定的 3 組 160x80 原創場景（舊編號 01/02/06）。
 * [保留] NEBULA/DIAL/TORQUE 各自原始構圖。
 * [修改] 改接 Model/Curve/History 真實資料；無硬編碼示範轉速。
 * [保留] 僅呼叫 Adafruit GFX 繪圖 API，不含 LCD 驅動命令。
 * [修改] 充電 UI：僅保留電池內亮帶，不顯示閃電、三點或 CHG 文字。
 */
#include <Adafruit_GFX.h>
#include <cstdio>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <algorithm>
#include "brd_ui_style_scene.h"
#include "brd_ui_warning_pages.h"
#include "brd_ui_types.h"
#include "brd_ui_curve.h"
#include "brd_ui_legible_text.h" // [新增] 次要文字改用現成 U8g2 字型庫。
#include "brd_config.h" // [新增] 三風格 RPM 指示條滿格轉速由 CFG 設定。
namespace brd_ui { namespace style_scene {
namespace {
static Adafruit_GFX* gfx = nullptr;
#define lcd (*gfx)
static constexpr int W=160, H=80;
// [修改] 避免 Arduino ESP32 Core 的 PI 巨集與本地常數名稱衝突。
constexpr double kBrdPi=3.14159265358979323846;
static int bound_int(int v,int lower,int upper) {return v<lower?lower:(v>upper?upper:v);}
static float bound_float(float v,float lower,float upper) {return v<lower?lower:(v>upper?upper:v);}
static uint16_t rgb(int r,int g,int b){ return ((r>>3)<<11)|((g>>2)<<5)|(b>>3); }
static uint16_t mix(uint16_t a,uint16_t b,float t){
    auto r=[](uint16_t c){return int(((c>>11)&31)*255/31);};
    auto g=[](uint16_t c){return int(((c>>5)&63)*255/63);};
    auto bl=[](uint16_t c){return int((c&31)*255/31);};
    t=bound_float(t,0.0f,1.0f);
    return rgb(int(r(a)*(1-t)+r(b)*t),int(g(a)*(1-t)+g(b)*t),int(bl(a)*(1-t)+bl(b)*t));
}
struct Theme {const char* key;const char* name;uint16_t bg,fg,hi,lo,warn,red;};
static const Theme T[] = {
{"01_NEBULA","NEBULA",rgb(4,10,23),rgb(232,248,255),rgb(75,227,228),rgb(19,62,87),rgb(255,194,98),rgb(255,97,122)},
{"02_DIAL","DIAL",rgb(8,10,15),rgb(242,246,248),rgb(250,183,88),rgb(57,63,75),rgb(255,224,101),rgb(255,104,91)},
{"06_TORQUE","TORQUE",rgb(20,9,5),rgb(255,240,229),rgb(250,124,77),rgb(100,48,27),rgb(255,211,88),rgb(255,83,95)},
};
// [新增] 新索引 0..2 到原始風格編號 (0-based)，保留原構圖分支、警告圖示版型。
static constexpr uint8_t kLegacyStyleId[3] = {0U,1U,5U};
static uint8_t original_style(int selected) {return kLegacyStyleId[selected];}
// [修改] 原 size=1 的 6x8 小字改為 U8g2 7x13 可讀字型，保留 size=2/3 原尺寸。
static void txt(int x,int y,const char* s,uint16_t c,int size=1){
    if(size==1){legible_text::draw(lcd,x,y,s,c);return;}
    lcd.setCursor(x,y);lcd.setTextSize(size);lcd.setTextColor(c);lcd.print(s);
}
// [新增] 狹窄欄位用 U8g2 6x10 字型，保留 5 位歷史 RPM、OTA 長字串。
static void txt_compact(int x,int y,const char* s,uint16_t c){
    legible_text::draw(lcd,x,y,s,c,legible_text::Density::Compact);
}
static void centered(int y,const char* s,uint16_t c,int size=1){
    int w=size==1?legible_text::width(lcd,s):(int)strlen(s)*6*size;
    txt(std::max(0,(160-w)/2),y,s,c,size);
}
static void line(int x,int y,int xx,int yy,uint16_t c){lcd.drawLine(x,y,xx,yy,c);}
static void box(int x,int y,int w,int h,uint16_t c){lcd.drawRect(x,y,w,h,c);}
static void fill(int x,int y,int w,int h,uint16_t c){lcd.fillRect(x,y,w,h,c);}
static void circ(int x,int y,int r,uint16_t c){lcd.drawCircle(x,y,r,c);}
static void disk(int x,int y,int r,uint16_t c){lcd.fillCircle(x,y,r,c);}
static void arc(int cx,int cy,int r,float a1,float a2,uint16_t c,int width=1){
    for(int w=0;w<width;w++)for(float a=a1;a<a2;a+=4.5f){
        float e=std::min(a+4.5f,a2);
        int x=cx+int((r-w)*std::cos(a*kBrdPi/180)), y=cy+int((r-w)*std::sin(a*kBrdPi/180));
        int xx=cx+int((r-w)*std::cos(e*kBrdPi/180)),yy=cy+int((r-w)*std::sin(e*kBrdPi/180));line(x,y,xx,yy,c);
    }
}
static void fmt(char*b,size_t n,uint32_t v){std::snprintf(b,n,"%lu",(unsigned long)v);}
// [修改] 充電時只保留電池內流動亮帶，移除外部閃電。
// [保留] 電量格數依實際 ADC 百分比，不把動畫當成真實電量。
// [範圍] x..x+18, y..y+7；支援 MAIN 與 IR TEST，避免覆蓋 BLE/電壓。
static void battery(const Theme &t,int x,int y,int pct,bool charge,uint8_t phase){
    const int p=bound_int(pct,0,100);
    const uint16_t body=charge?t.hi:t.fg;
    box(x,y,17,8,body);
    fill(x+17,y+2,2,4,body);
    const int bar=12*p/100;
    if(bar>0) {
        fill(x+2,y+2,bar,4,charge?mix(t.bg,t.hi,0.60f):(p<20?t.red:t.hi));
    }
    if(!charge) return;

    // [新增] 輕量動畫：2px 亮帶只掃過已充入的部分，不偽造電池容量。
    if(bar>0) {
        const int scan=(bar<=2)?0:((int)(phase%4U)*(bar-2)/3);
        fill(x+2+scan,y+2,std::min(2,bar-scan),4,t.fg);
    }
}
/* [新增] Standard Bluetooth glyph drawn only inside the top-right BLE slot.
 * [修改] Replace the ambiguous connection dot with an identifiable BT rune.
 * Connected: theme accent; advertising/waiting: subdued gray;
 * BLE disabled: red with a diagonal slash.
 * Bounds: x-4..x+5, y..y+12 (does not touch the battery icon).
 */
static void ble_icon(const Theme &t,int x,int y,bool connected,bool disabled) {
    const uint16_t muted=mix(t.bg,t.fg,0.43f);
    const uint16_t color=disabled?t.red:(connected?t.hi:muted);
    line(x,y,x,y+12,color);                    // Main vertical stroke
    line(x,y,x+4,y+4,color);                   // Upper triangle
    line(x+4,y+4,x-3,y+9,color);               // Upper diagonal
    line(x-3,y+3,x+4,y+9,color);               // Lower diagonal
    line(x+4,y+9,x,y+12,color);                // Lower triangle
    if(disabled) {
        line(x-4,y+12,x+5,y,color);           // BLE intentionally disabled
    }
}

static void base(const Theme&t){lcd.fillScreen(t.bg);}

// [變更] 曲線資料來自量測快照，不再使用 DEMO 陣列。
static const brd_ui::Curve* active_curve = nullptr;
static void graph(const Theme&t,int x,int y,int w,int h,int type,int frame){
  uint16_t grid=mix(t.bg,t.lo,.7f);
  for(int i=0;i<=3;i++)line(x,y+i*h/3,x+w-1,y+i*h/3,grid);
  if(type%3==0)for(int i=1;i<5;i++)line(x+i*w/5,y,x+i*w/5,y+h,grid);
  int actual = active_curve ? active_curve->count : 0;
  int n=std::min(actual,std::max(0,4+frame*3));
  int divisions = actual > 1 ? actual-1 : 1;
  uint32_t peak = active_curve && active_curve->peak ? active_curve->peak : 1U;
  int xx0=0,yy0=0;
  for(int i=0;i<n;i++){
    int px=x+i*(w-1)/divisions;
    int py=y+h-1-int((h-4)*(uint32_t)active_curve->rpm[i]/peak);
    if(i){
      if(type%4==0||type%4==1)line(xx0,yy0,px,py,t.hi);
      if(type%4==2){line(xx0,yy0,px,py,t.hi);line(px,py,px,y+h-1,mix(t.hi,t.bg,.78f));}
      if(type%4==3)disk(px,py,1,t.hi);
    }
    xx0=px;yy0=py;
  }
}



// [修改] W1 呼吸文字置中、不帶尾點；L2 聚焦鎖定置中，套用於 NEBULA/TORQUE。
// [保留] LOAD/RPM 量測邏輯完全不變；畫面仍使用真實量測快照。
// [防重疊] WAIT/LOADED 使用相同中心；L2 括號始終與文字保留至少 5px 間距。
// [防重疊] 狀態區都在 y<63 且與右上角 BLE/電池、轉速數字分開。
static void load_state_effect(const Theme &t,int tick,bool loaded,int xmin,int xmax,int y){
    const char *label = loaded ? "LOADED" : "WAIT LOAD";
    const int width = legible_text::width(lcd,label,legible_text::Density::Compact);
    if(!loaded){
        // [W1 新增] 約 1.6 秒一次的三角波呼吸，零 delay、零浮點三角函數。
        const int phase=tick%48;
        const int triangle=(phase<24)?phase:(48-phase);
        const float level=0.38f+(float)triangle*(0.57f/24.0f);
        const uint16_t color=mix(t.bg,t.hi,level);
        // [修改] WAIT LOAD 和 LOADED 使用相同的狀態區水平中心。
        // [刪除] WAIT LOAD 末端呼吸點；只保留文字本身的 W1 呼吸效果。
        const int text_x=(xmin+xmax-width)/2;
        txt_compact(text_x,y,label,color);
        return;
    }
    // [L2 新增] 約 8 幀向內收束，完成後保持；不進入文字包圍框內側。
    const int text_x=(xmin+xmax-width)/2;
    txt_compact(text_x,y,label,mix(t.hi,t.fg,0.30f));
    const int shift=std::max(0,7-std::min(7,tick));
    const int left=text_x-8-shift;
    const int right=text_x+width+7+shift;
    const uint16_t color=mix(t.hi,t.fg,0.37f);
    const int top=y-1;
    const int bottom=y+10;
    // [L2 防重疊] 左右括號水平短邊只向外畫，與文字最近仍相隔至少 5px。
    line(left,top,left,bottom,color);
    line(left,top,left+2,top,color);
    line(left,bottom,left+2,bottom,color);
    line(right,top,right,bottom,color);
    line(right-2,top,right,top,color);
    line(right-2,bottom,right,bottom,color);
}

static void main_scene(int s,int tick,const brd_ui::Model& m){
 const Theme&t=T[s];base(t);
 // [新增] 量測模組在 show_max 時已把最高轉速放入 measurement.value。
 // [修改] 在原本 MAIN 版型內切換 MAX SP，無須進入獨立 MAX 頁。
 const bool show_peak=m.measurement.show_max;
 const uint16_t peak_color=show_peak?t.warn:t.fg;
 // [修改] 只改主畫面顯示值；曲線與 BLE 仍使用即時 RPM。
 // 正式量測提供 peak_value，舊預覽 Model 沒有設定時退回 value。
 const uint32_t rpm=std::max(uint32_t(m.measurement.value),uint32_t(m.measurement.peak_value));
 char val[24];fmt(val,sizeof val,rpm);
 // [修改] 三風格共用滿格 RPM，比值僅用於 UI；避免 uint32_t 乘法溢位。
 // [新增] RPM 超過 BRD_UI_INDICATOR_FULL_SCALE_RPM 時固定滿格，但不截斷數值。
 const uint32_t full_scale=BRD_UI_INDICATOR_FULL_SCALE_RPM;
 const int filled=(rpm>=full_scale) ? 100 :
     static_cast<int>((static_cast<uint64_t>(rpm)*100ULL)/full_scale);
 switch(original_style(s)){
 case 0:{ // [修改] NEBULA 原圖形：三階段雙環，黃色旋轉與藍色 RPM 外圈分開控制
  const uint16_t kYellow = rgb(255,211,61);
  const bool measurement_complete = m.measurement.show_max;
  const bool spinning = rpm > 0U;
  const bool loaded_or_spinning = m.measurement.loaded || spinning;
  // [新增] LOAD 模式必須在裝載解除後才點亮藍圈；AUTO 模式以有效 RPM 啟動。
  // [保留] MAX 完成時即使 LOAD 狀態改變，仍顯示最終最高轉速藍圈。
  const bool launched = measurement_complete ||
      (spinning && (m.mode_auto || !m.measurement.loaded));
  // [修改] 未裝載/已裝載/LIVE/MAX 皆保留 NEBULA 內外圈的暗色底環。
  // [新增] 待機時仍清楚可見青藍外圈與黃色內圈，僅降低底環亮度。
  // [保留] 明亮的藍色進度弧與黃色旋轉弧另行疊加，不混用其顏色。
  const uint16_t blue_track = mix(t.bg,t.hi,0.37f);
  const uint16_t yellow_track = mix(t.bg,kYellow,0.45f);
  circ(41,40,32,blue_track);
  circ(41,40,27,blue_track);
  circ(41,40,21,yellow_track);
  // [修改] 只有 LIVE（發射）與 MAX 顯示藍色 SP 指示弧。
  // [新增] 20,000 RPM（可於 CFG 修改）對應一整圈，超過保持滿圈。
  if(launched && filled>0) {
    arc(41,40,29,-90,-90+filled*3.6f,t.hi,3);
  }
  if(!measurement_complete && loaded_or_spinning) {
    // [保留] 裝載後亮黃色內圈啟動旋轉；發射後持續旋轉，MAX 時停止。
    // [修改] 旋轉幀序由 50 ms UI 排程推進，一圈 20 幀。
    const float angle=-90.0f+float(tick%20)*18.0f;
    arc(41,40,21,angle,angle+70.0f,kYellow,2);
  }
  txt(26,36,show_peak?"MX":"SP",peak_color,2);
  // [修改] WAIT LOAD=W1（置中無尾點）、LOADED=L2（同中心），狀態區 x=80..156、y=22..32。
  // [防重疊] 外圈最大 x=73；電池列 y<=16；轉速數值從 y=36 開始。
  if(!show_peak && !launched) {
    load_state_effect(t,tick,m.measurement.loaded,80,156,22);
  } else {
    txt_compact(87,22,show_peak?"MAX SP":"LIVE",show_peak?t.warn:t.hi);
  }
  txt(80,36,val,peak_color,2);
  // [刪除] 數字下方的第二個 SP；左側圓環內的 SP 已足夠標示轉速。
  break;}
 case 1:{ // independent compact dial on left, speed field on right
  arc(42,48,29,145,395,t.lo,3);
  arc(42,48,28,145,145+250*filled/100,t.hi,3);
  double theta=(145+250*filled/100)*kBrdPi/180;
  line(42,48,42+int(21*std::cos(theta)),48+int(21*std::sin(theta)),t.warn);
  disk(42,48,3,t.fg);
  // [刪除] DIAL 正常轉速畫面左上角 TACHO；保留 MAX 模式的 MAX SP。
  if(show_peak) txt(6,3,"MAX SP",t.warn,2);
  txt(80,30,val,peak_color,2);
  // [保留] 左下角唯一的 SP/MAX 主標籤。
  txt(15,65,show_peak?"MAX":"SP",show_peak?t.warn:mix(t.lo,t.fg,0.55f));
  // [恢復] 風格 1（DIAL，索引 1）的 W1 呼吸 WAIT LOAD 與 L2 鎖定 LOADED。
  // [防重疊] 狀態區 x=80..158、y=66..76，與左側 SP、儀表及速度數字分離。
  if(!show_peak && (m.measurement.loaded || rpm==0U)) {
    load_state_effect(t,tick,m.measurement.loaded,80,158,66);
  }
  break;}
 case 5:{ // torque horizontal industrial block
  fill(0,0,54,80,t.lo);
  txt(3,8,show_peak?"MAX":"SP",t.warn,3);
  // [刪除] 風格 2（TORQUE，索引 2）左側 SP 下方的 LOAD 狀態文字。
  // [保留] MAX 模式的 PEAK 文字，其他區域及右側 W1/L2 狀態特效不變。
  if(show_peak) txt(4,53,"PEAK",t.fg);
  txt(60,25,val,peak_color,2);
  // [刪除] 數字下方第二個 SP/MAX SP；保留左側主標示與 L2 狀態特效。
  if(!show_peak && (m.measurement.loaded || rpm==0U)) {
    // [防重疊] 狀態特效維持右側獨立區域，數值與文字不互相覆蓋。
    load_state_effect(t,tick,m.measurement.loaded,91,159,48);
  }
  for(int i=0;i<16;i++)fill(61+i*6,65,4,7,i<filled*16/100?t.hi:t.lo);
  break;}

 }
 // [修改] MAIN 頁移除充電閃電，保留電池亮帶、電量百分比與 BLE 圖示。
 // [保留] 只使用原本 x=90..159、y=0..16 的狀態列空間。
 fill(90,0,70,17,t.bg);
 battery(t,105,4,m.battery,m.charging,m.charge_phase);
 char bp[8];std::snprintf(bp,sizeof bp,"%u%%",(unsigned)m.battery);
 txt_compact(133,3,bp,t.fg);
 // [保留] 藍牙圖示位置與顏色不變。
 ble_icon(t,96,2,m.connected,m.ble_disabled);
 // [刪除] Bottom-right WAIT LOAD/LOADED/READY/HOLD/SAVED status strip.
 // Keep the nine original layouts and free this region for artwork.
}
static void result_scene(int s,int tick,const brd_ui::Model&m){
 const Theme&t=T[s];base(t);char v[20];fmt(v,sizeof v,m.measurement.value);
 if(original_style(s)%3==0){for(int r=8;r<73;r+=13)arc(80,44,r,-90,-90+tick*32,t.lo,2);}
 if(original_style(s)%3==1){for(int x=0;x<160;x+=17)fill(x,(tick*6+x)%80,10,2,t.lo);}
 if(original_style(s)%3==2){for(int j=0;j<5;j++)line(10,14+j*13,150,14+j*13,t.lo);for(int j=0;j<=tick;j++)fill(4+j*9,22,5,3,t.hi);}
 txt(5,3,original_style(s)%2==0?"SHOT MAX":"NEW PEAK",t.hi,2);
 centered(31,v,t.warn,3);
 txt(6,66,"SAVED",t.hi);txt(111,66,"SP",t.fg);
}
static void graph_scene(int s,int tick,const brd_ui::Model&m,const brd_ui::Curve &c){
 const Theme&t=T[s];base(t);(void)m;
 if(original_style(s)==1||original_style(s)==6){txt(6,2,"SP TRACE",t.fg);graph(t,5,19,150,47,original_style(s),tick);} 
 else if(original_style(s)==7){txt(5,3,"TIMELINE",t.lo);graph(t,5,18,150,46,original_style(s),tick);}
 else if(original_style(s)==3){txt(6,2,"VELOCITY",t.hi,2);graph(t,4,23,152,45,original_style(s),tick);}
 else {txt(6,2,"CURVE",t.hi,2);graph(t,3,22,154,44,original_style(s),tick);}
 char v[20];fmt(v,sizeof v,c.peak);txt(6,66,"MAX",t.warn);txt(34,66,v,t.fg);
}
// Original IR sensor geometry is copied verbatim from production brd_ui_page_ir.cpp.
// [保留] LOAD uses k_hexagon with x=44,y=36, zoom=2; RPM uses
// k_trapezoid with x=93,y=28, zoom=2. No redesigned symbol shapes.
static constexpr int8_t k_hexagon[6][2]={{16,7},{12,14},{4,14},{0,7},{4,0},{12,0}};
static constexpr int8_t k_trapezoid[6][2]={{0,4},{0,18},{10,22},{13,20},{13,2},{10,0}};
static void original_sensor(int x,int y,const int8_t p[][2],bool active,const Theme &t,uint16_t active_color){
    uint16_t color=active?active_color:mix(t.bg,t.lo,.85f);
    for(int i=0;i<6;i++){int j=(i+1)%6;
      lcd.drawLine(x+p[i][0]*2,y+p[i][1]*2,x+p[j][0]*2,y+p[j][1]*2,color);
    }
    if(active){
      for(int i=1;i<5;i++){
        lcd.fillTriangle(x+p[0][0]*2,y+p[0][1]*2,
          x+p[i][0]*2,y+p[i][1]*2,x+p[i+1][0]*2,y+p[i+1][1]*2,color);
      }
    }
}
static void sensor_scene(int s,int tick,const brd_ui::Model&m){
 const Theme&t=T[s];base(t);
 const int lp=bound_int(int(m.load_adc_raw)*100/4095,0,100);
 const int rp=bound_int(int(m.rpm_adc_raw)*100/4095,0,100);
 char left[12],right[12];fmt(left,sizeof(left),m.load_adc_raw);fmt(right,sizeof(right),m.rpm_adc_raw);
 const uint16_t adc_orange=t.warn;
 const uint16_t adc_yellow=mix(t.warn,t.fg,0.42f);
 // Distinct layout accents; the original polygon coordinates never change.
 switch(original_style(s)%5){
 case 0:line(0,19,159,19,t.lo);line(36,22,36,78,t.lo);line(125,22,125,78,t.lo);break;
 case 1:box(1,23,34,54,t.lo);box(126,23,33,54,t.lo);break;
 case 2:for(int i=0;i<6;i++){line(0,20+i*10,34,20+i*10,t.lo);line(126,20+i*10,159,20+i*10,t.lo);}break;
 case 3:line(37,18,37,79,t.hi);line(124,18,124,79,t.hi);break;
 case 4:for(int i=0;i<7;i++){fill(0,22+i*8,3,3,t.lo);fill(157,22+i*8,3,3,t.lo);}break;
 }
 txt(3,3,"IR TEST",t.hi,2);
 // [修改] IR TEST 電池電壓使用真實 mV，且保留電池內部充電流光。
 // [修改] IR TEST 移除充電閃電及三點，保留電池亮帶與電壓。
 battery(t,93,4,m.battery,m.charging,m.charge_phase);
 char voltage[10];
 std::snprintf(voltage,sizeof(voltage),"%u.%02uV",
   (unsigned)(m.voltage_mv/1000U),(unsigned)((m.voltage_mv%1000U)/10U));
 txt(121,3,voltage,t.fg);
 txt(4,24,"LOAD",t.hi);
 txt(140,24,"SP",adc_orange);
 // [修改] 左右 ADC 條狀內部填充改為橘/黃跳色；中間原始圖形維持主題色。
 switch(original_style(s)%4){
 case 0:for(int i=0;i<9;i++){
   const uint16_t lc=(i%2==0)?adc_orange:adc_yellow;
   const uint16_t rc=(i%2==0)?adc_yellow:adc_orange;
   fill(6,36+3*i,23,2,(8-i)*100/9<lp?lc:t.lo);
   fill(132,36+3*i,21,2,(8-i)*100/9<rp?rc:t.lo);
 }break;
 case 1:box(9,36,12,28,t.lo);box(139,36,12,28,t.lo);
   fill(11,62-lp*24/100,8,lp*24/100,adc_orange);
   fill(141,62-rp*24/100,8,rp*24/100,adc_yellow);
   break;
 case 2:for(int i=0;i<6;i++){
   fill(5+i*4,38,3,19,i*100/6<lp?((i%2)?adc_yellow:adc_orange):t.lo);
   fill(131+i*4,38,3,19,i*100/6<rp?((i%2)?adc_orange:adc_yellow):t.lo);
 }break;
 case 3:box(4,40,26,9,t.lo);box(130,40,26,9,t.lo);
   fill(6,42,lp*22/100,5,adc_orange);
   fill(132,42,rp*22/100,5,adc_yellow);
   fill(6,55,lp*22/100,2,adc_yellow);
   fill(132,55,rp*22/100,2,adc_orange);
   break;
 }
 txt(4,66,left,t.fg);txt(127,66,right,t.fg);
 // [保留] EXACT shape geometry from production firmware.
 const bool load_trigger=m.ir2, rpm_trigger=m.ir1;
 original_sensor(44,36,k_hexagon,load_trigger,t,t.hi);
 original_sensor(93,28,k_trapezoid,rpm_trigger,t,t.hi);
 // [新增] Independent LED-like indicator dot: triggered -> bright, not triggered -> dim.
 disk(78,70,2,load_trigger?adc_orange:t.lo);
 disk(122,70,2,rpm_trigger?adc_yellow:t.lo);
 (void)tick;
}
static void history_scene(int s,int tick,const brd_ui::Model& m){
 const Theme&t=T[s];base(t);
 char total[12];fmt(total,sizeof total,m.history_count);
 if(original_style(s)%3==0){
  txt(5,2,"SHOT LOG",t.hi,2);txt(129,3,total,t.fg);
  for(int i=0;i<4;i++){
   if(i > tick/2 || i>=m.history_count) continue;
   char value[16];fmt(value,sizeof value,(i<m.history_count?m.history[i]:0U));
   int yy=23+i*13;txt(5,yy,i==0?"01":"  ",i==0?t.warn:t.lo);txt(36,yy,value,i==0?t.fg:t.hi);
   fill(91,yy+1,62*(i<m.history_count?m.history[i]:0U)/33000,5,i==0?t.warn:t.hi);
  }
 } else if(original_style(s)%3==1){
  txt(5,2,"RECENT",t.hi,2);txt(111,2,"MAX SP",t.fg);
  for(int i=0;i<4;i++){
   if(i > tick/2 || i>=m.history_count) continue;
   char value[16];fmt(value,sizeof value,(i<m.history_count?m.history[i]:0U));
   int x=5+i*38;int h=39*(i<m.history_count?m.history[i]:0U)/33000;
   fill(x+8,62-h,20,h,i==0?t.warn:t.hi);txt_compact(x+2,66,value,t.fg);
  }
 } else {
  txt(4,3,"HISTORY",t.hi,2);
  for(int i=0;i<4;i++){
   if(i > tick/2 || i>=m.history_count) continue;
   char value[16];fmt(value,sizeof value,(i<m.history_count?m.history[i]:0U));
   int yy=25+i*12;
   if(i==tick/4%4)fill(2,yy-2,156,11,t.lo);
   txt(6,yy,value,i==0?t.warn:t.fg);
   int v=(i<m.history_count?m.history[i]:0U)*40/33000;
   fill(92,yy,48*v/40,5,t.hi);
  }
 }
}

// [修改] LOW BATTERY 與 ADC FAULT 改由獨立模組繪製。
// [移除] 先前共用的警告畫面與大電池 / 格線共通樣式。
// [保留] 每個主題沿用相同 Theme 配色，並由 Dirty Tile 分段傳輸。
static void warning_scene(int s,int fault,int tick){
 const Theme&t=T[s];
 const warning_pages::Palette p{t.bg,t.fg,t.hi,t.lo,t.warn,t.red};
 warning_pages::draw(lcd,original_style(s),
   fault ? warning_pages::Kind::AdcFault : warning_pages::Kind::LowBattery,
   (uint8_t)tick,p);
}
static void boot_scene(int s,int tick){
 const Theme&t=T[s];base(t);
 const uint16_t soft=mix(t.bg,t.lo,0.78f);
 const uint16_t glow=mix(t.hi,t.fg,0.25f);
 switch(original_style(s)){
 case 0:
   centered(7,"BRD",soft,2);
   arc(80,42,27,-90,-90+tick*18,t.hi,3);
   arc(80,42,19,180+tick*10,280+tick*10,t.warn,2);
   centered(29,"BPX PRO",t.fg,2);
   centered(66,"BOOTING",glow,1);
   break;
 case 1:
   txt(10,9,"BRD",t.hi,2); txt(11,29,"BPX PRO",t.fg,2);
   arc(122,39,24,135,135+tick*18,t.hi,3); disk(122,39,3,t.warn);
   txt(95,64,"INIT",t.fg,1); break;
 case 5:
   fill(0,0,54,80,t.lo); txt(6,10,"BRD",t.warn,2); txt(7,31,"BPX",t.fg,2); txt(7,52,"PRO",t.fg,2);
   txt(66,18,"BOOT",t.hi,2); txt(66,40,"SYSTEM",t.fg,2);
   for(int i=0;i<8;i++) { fill(68+i*10,66,6,5,i<tick/2?t.hi:soft); } break;

 }
}
static void ota_scene(int s,int tick,const brd_ui::Model& m){
 (void)tick;
 const Theme&t=T[s];base(t);
 const uint8_t percent=m.ota.percent>100U?100U:m.ota.percent;
 const int filled=int(percent);
 const uint16_t soft=mix(t.bg,t.lo,0.82f);
 const uint16_t alt=mix(t.warn,t.fg,0.35f);
 char pct[8]; std::snprintf(pct,sizeof pct,"%u%%",(unsigned)percent);
 const char* title=m.ota.verifying?"VERIFY":"OTA";
 const char* sub=(m.ota.phase==brd_ota::COMPLETE)?"DONE":(m.ota.verifying?"CHECK FLASH":"UPDATING");
 switch(original_style(s)){
 case 0:
   centered(5,title,t.hi,2); arc(42,42,27,-90,-90+filled*3.6f,t.hi,3); arc(42,42,19,-90,-90+filled*3.6f,alt,2);
   txt(80,23,pct,t.fg,2); txt_compact(80,47,sub,t.hi); fill(80,60,70,4,soft); fill(80,60,70*filled/100,4,t.warn); break;
 case 1:
   txt(8,8,"OTA",t.hi,2); txt(8,27,pct,t.fg,3); arc(122,41,24,135,135+250*filled/100,t.hi,3); disk(122,41,3,t.warn); txt_compact(79,64,sub,t.fg); break;
 case 5:
   fill(0,0,54,80,t.lo); txt(6,8,"OTA",t.warn,3); txt(8,54,"BLE",t.fg,2); txt(62,19,pct,t.fg,2); if(strlen(sub)>8U)txt_compact(63,45,sub,t.hi);else txt(63,42,sub,t.hi,2); for(int i=0;i<16;i++) fill(61+i*6,65,4,7,i<filled*16/100?t.hi:soft); break;

 }
}

} // namespace
void draw(Adafruit_GFX& target,uint8_t selected,Page page,uint8_t frame,
          const Model& model,const Curve& curve) {
    gfx=&target;
    const int s=(int)(selected%3U);
    active_curve=&curve;
    const int tick=(int)frame;
    switch(page) {
        case Page::Main: main_scene(s,tick,model);break;
        case Page::Max: result_scene(s,tick,model);break;
        case Page::Graph: graph_scene(s,tick,model,curve);break;
        case Page::History: history_scene(s,tick,model);break;
        case Page::IrTest: sensor_scene(s,tick,model);break;
        case Page::Ota: ota_scene(s,tick,model);break;
        case Page::LowBattery: warning_scene(s,0,tick);break;
        case Page::AdcFault: warning_scene(s,1,tick);break;
        case Page::Boot: boot_scene(s,tick);break;
        default:break;
    }
    gfx=nullptr;
}
} } // namespace brd_ui::style_scene
