/* 檔案: BRD_BPX_PRO/brd_ui_curve.h
 * [新增] UI 專用 RAM 即時曲線，不改動 BBP 官方 32 點封包、Flash 紀錄。
 */
#ifndef BRD_UI_CURVE_H
#define BRD_UI_CURVE_H
#include <stdint.h>
#include "brd_config.h"
#include "brd_measurement.h"
namespace brd_ui {
struct Curve {
    uint16_t rpm[UI_CURVE_POINTS] = {};
    uint8_t count = 0;
    uint16_t peak = 0;
    bool frozen = false;
    uint32_t version = 0;
};
void curve_begin();
void curve_observe(const brd_display_t &reading, uint32_t time_ms);
const Curve &curve_snapshot();
}
#endif
