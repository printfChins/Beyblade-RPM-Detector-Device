/* File: BRD_BPX_PRO/brd_ui_style_scene.h
 * [新增] 純 GFX 3 風格場景；不持有 SPI 或 ST7735 硬體。
 */
#ifndef BRD_UI_STYLE_SCENE_H
#define BRD_UI_STYLE_SCENE_H
#include <stdint.h>
#include "brd_ui_types.h"
#include "brd_ui_curve.h"
#include <Adafruit_GFX.h>
namespace brd_ui { namespace style_scene {
void draw(Adafruit_GFX& target,uint8_t theme,Page page,uint8_t frame,
          const Model& model,const Curve& curve);
} }
#endif
