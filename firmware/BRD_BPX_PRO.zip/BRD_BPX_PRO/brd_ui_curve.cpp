/* 檔案: BRD_BPX_PRO/brd_ui_curve.cpp
 * [新增] RAM 最長 5 秒曲線，100ms 一點，獨立於畫面頁面切換。
 * [保留] 測速 BLE/Flash 曲線演算法完全不變；僅使用 UI 顯示數據。
 */
#include "brd_config.h"
#include "brd_ui_curve.h"
namespace brd_ui {
namespace {
Curve points;
uint32_t last_sample_ms = 0;
bool sampling = false;
}
void curve_begin() {
    points = {};
    last_sample_ms = 0U;
    sampling = false;
}
void curve_observe(const brd_display_t &reading, uint32_t time_ms) {
    // [新增] MAX 顯示的是最高值，不是即時 RPM：完成後保留整筆曲線。
    if (reading.show_max) {
        if (sampling) {
            points.frozen = true;
            points.version++;
            sampling = false;
        }
        return;
    }
    if (!sampling && reading.value == 0U) { return; }
    if (!sampling) {
        // [新增] 新一發首次有效 RPM 才清掉舊曲線，換頁不清除。
        points = {};
        sampling = true;
        last_sample_ms = time_ms - UI_CURVE_SAMPLE_MS;
    }
    if ((uint32_t)(time_ms - last_sample_ms) < UI_CURVE_SAMPLE_MS) { return; }
    last_sample_ms = time_ms;
    if (points.count >= UI_CURVE_POINTS) { return; }
    const uint16_t rpm = reading.value;
    points.rpm[points.count++] = rpm;
    if (rpm > points.peak) { points.peak = rpm; }
    points.version++;
}
const Curve &curve_snapshot() { return points; }
}
