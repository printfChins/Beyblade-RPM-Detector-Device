/*
 * File: BRD_BPX_PRO/brd_ui_warning_pages.cpp
 * [新增] 只保留 3 種風格對應的低電／ADC 警告頁構圖。
 * [保留] 使用原生 Adafruit_GFX 繪圖 API；不建立自製 TFT 驅動。
 * [設計] LOW BATTERY 使用電池最後一格紅色電量持續閃爍；ADC FAULT 必須有
 *        帶斷線記號的感測器 IC，兩者均具有清楚的文字提示。
 * [效能] 畫面交給 brd_ui_dirty_presenter 做 8x16 Tile 差異比對。
 */
#include "brd_ui_warning_pages.h"
#include "brd_ui_legible_text.h" // [新增] 警告頁次要字體改用 U8g2。
#include <cmath>
#include <cstring>
namespace brd_ui { namespace warning_pages {
namespace {
constexpr int W=160, H=80;
// [修改] Arduino.h 已定義 PI 巨集，改用獨立常數名稱避免展開衝突。
constexpr float kBrdPi = 3.14159265358979323846f;
struct Rect { int x,y,w,h; };

static void h(Adafruit_GFX& g, int x, int y, int w,uint16_t c) {g.drawFastHLine(x,y,w,c);}
static void line(Adafruit_GFX& g,int x,int y,int xx,int yy,uint16_t c) {g.drawLine(x,y,xx,yy,c);}
static void rect(Adafruit_GFX& g,int x,int y,int w,int ht,uint16_t c) {g.drawRect(x,y,w,ht,c);}
static void fill(Adafruit_GFX& g,int x,int y,int w,int ht,uint16_t c) {g.fillRect(x,y,w,ht,c);}
static void label(Adafruit_GFX&g,int x,int y,const char *s,uint16_t c,uint8_t scale=1U) {
    // [修改] 所有 scale=1 文字不再使用 6x8，避免警告說明過小。
    if(scale==1U){legible_text::draw(g,x,y,s,c);return;}
    g.setTextWrap(false);
    g.setTextSize(scale);
    g.setTextColor(c);
    g.setCursor(x,y);
    g.print(s);
}
static void center(Adafruit_GFX&g,int y,const char *s,uint16_t c,uint8_t size=1U) {
    int width=size==1U ? legible_text::width(g,s) : (int)std::strlen(s)*6*(int)size;
    label(g,(W-width)/2,y,s,c,size);
}
static void arc(Adafruit_GFX&g,int x,int y,int r,int begin,int end,uint16_t c) {
    for(int a=begin;a<end;a+=8) {
        int b=(a+8<end)?a+8:end;
        float p=float(a)*kBrdPi/180.0f,q=float(b)*kBrdPi/180.0f;
        line(g,x+int(r*std::cos(p)),y+int(r*std::sin(p)),
               x+int(r*std::cos(q)),y+int(r*std::sin(q)),c);
    }
}
static uint16_t subdued(uint16_t a,uint16_t b) {
    // [新增] 低亮度主題線條：55% 背景、45% muted。
    int ar=(a>>11)&31,ag=(a>>5)&63,ab=a&31;
    int br=(b>>11)&31,bg=(b>>5)&63,bb=b&31;
    return (uint16_t)(((ar*11+br*9)/20<<11)|((ag*11+bg*9)/20<<5)|((ab*11+bb*9)/20));
}
static void motifs(Adafruit_GFX &g, uint8_t style, const Palette &p) {
    uint16_t m=subdued(p.background,p.muted);
    switch(style) {
    case 0: // NEBULA：雙軌環
        g.drawCircle(36,43,31,m);g.drawCircle(36,43,25,p.muted);
        arc(g,36,43,30,-95,-25,p.accent);break;
    case 1: // DIAL：指針刻度盤
        arc(g,39,48,31,146,394,p.muted);
        for(int a=150;a<=390;a+=30) {
            float t=float(a)*kBrdPi/180;
            line(g,39+int(27*std::cos(t)),48+int(27*std::sin(t)),
                   39+int(31*std::cos(t)),48+int(31*std::sin(t)),p.accent);
        }
        break;
    case 5: // TORQUE：左側實心工業訊號區
        fill(g,0,0,53,80,p.muted);
        for(int y=6;y<73;y+=7) {h(g,0,y,49,m);}
        break;
    default: break;
    }
}
static Rect iconBounds(uint8_t style) {
    // [新增] 每種主題可使用不同警示資訊結構，但感測符號同樣清晰。
    switch(style%5) {
    case 0: return {18,31,43,27};     // 左圖示，右雙列文字
    case 1: return {51,31,59,27};     // 中央圖示
    case 2: return {108,31,42,26};    // 右圖示，左資訊
    case 3: return {51,30,58,27};     // 透視／網格中央圖示
    default:return {18,32,46,26};    // 工程面板左圖示
    }
}
static void drawBattery(Adafruit_GFX& g,const Rect&r,const Palette&p,uint8_t frame) {
    const uint16_t outline=p.foreground;
    // [保留] 各主題沿用自己的電池輪廓、凸極與原有配色。
    rect(g,r.x,r.y,r.w-5,r.h,outline);
    fill(g,r.x+r.w-5,r.y+r.h/3,5,r.h/3,outline);

    // [刪除] 電池內原本的驚嘆號與電池外額外的小燈。
    // [新增] 最後一格電量紅色閃爍（500 ms 亮 / 500 ms 滅）。
    // [效能] 紅色格以外的圖素完全固定，由 Dirty Tile 限縮 SPI 寫入。
    if((frame&1U)==0U) {
        fill(g,r.x+5,r.y+5,5,r.h-10,p.danger);
    }
}
static void drawAdc(Adafruit_GFX& g,const Rect&r,const Palette&p,uint8_t frame) {
    const uint16_t out=p.foreground;
    const int cx=r.x+4, cy=r.y+3, cw=r.w-11,ch=r.h-6;
    rect(g,cx,cy,cw,ch,out);
    // [新增] 兩側端子：一看便知道是感測/電路故障，不會與電池混淆。
    for(int i=0;i<3;i++){
        int yy=cy+5+i*(ch-8)/2;
        h(g,r.x,yy,4,p.accent);
        h(g,cx+cw,yy,4,p.accent);
    }
    // 斷線的 X 及警告中心符號。
    line(g,cx+cw/2-6,cy+5,cx+cw/2+6,cy+ch-5,p.warning);
    line(g,cx+cw/2+6,cy+5,cx+cw/2-6,cy+ch-5,p.warning);
    g.drawPixel(cx+cw/2,cy+ch/2,(frame&1U)?p.danger:p.warning);
}
static void message(Adafruit_GFX&g,uint8_t style,Kind kind,const Palette&p) {
    const bool low=(kind==Kind::LowBattery);
    const char *word1=low?"LOW":"ADC";
    const char *word2=low?"BATT":"FAULT";
    const char *foot=low?"CHARGE NOW":"CHECK INPUT";
    switch(style%5) {
    case 0: case 4:
        label(g,72,25,word1,p.foreground,2);
        label(g,72,43,word2,p.danger,2);
        label(g,72,65,foot,p.accent);break;
    case 1: case 3:
        center(g,3,low?"LOW BATTERY":"ADC FAULT",p.danger,2);
        center(g,64,foot,p.foreground,1);break;
    case 2:
        label(g,6,27,word1,p.foreground,2);
        label(g,6,46,word2,p.danger,1);
        label(g,6,67,low?"CHARGE":"CHECK IR",p.accent);break;
    default:break;
    }
}
}
void draw(Adafruit_GFX&gfx,uint8_t theme,Kind kind,uint8_t frame,const Palette&palette){
    // [保留] Dirty Presenter 比較整張 RGB565 畫布，實際 LCD 只更新有變化的 Tiles。
    gfx.fillScreen(palette.background);
    const uint8_t style=theme; // original style index from scene
    motifs(gfx,style,palette);
    // [新增] 動態主畫面的網格、賽道與波形不得穿過固定警告字元。
    // 每個警告欄只清理文字所需的面積，避免遮掉整個主題裝飾。
    switch(style%5U) {
    case 0U: case 4U:
        fill(gfx,70,22,90,58,palette.background);break;
    case 1U: case 3U:
        fill(gfx,11,1,138,20,palette.background);
        fill(gfx,34,63,92,17,palette.background);break;
    case 2U:
        fill(gfx,3,24,97,56,palette.background);break;
    default:break;
    }
    const Rect r=iconBounds(style);
    // [新增] 圖示背景清理，避免風格網格穿過電池或故障符號。
    fill(gfx,r.x-3,r.y-3,r.w+7,r.h+7,palette.background);
    if(kind==Kind::LowBattery)drawBattery(gfx,r,palette,frame);
    else drawAdc(gfx,r,palette,frame);
    message(gfx,style,kind,palette);
}
} }
