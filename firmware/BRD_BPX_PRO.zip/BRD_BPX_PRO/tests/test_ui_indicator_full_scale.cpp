/*
 * File: BRD_BPX_PRO/tests/test_ui_indicator_full_scale.cpp
 * [新增] 三種 UI 的指示條，驗證 0 / 50% / 100% / 超過滿格。
 * [新增] NEBULA 暗色雙環始終存在，黃色亮弧僅於 LOADED/LIVE 旋轉。
 * [保留] 最高轉速原始值不變，曲線獨立於指示條 CFG 滿格值。
 */
#include <Adafruit_GFX.h>
#include <cassert>
#include <cstdint>
#include <cstdio>
#include <vector>
#include "brd_config.h"
#include "brd_ui_style_scene.h"
#include "brd_ui_types.h"

namespace {
uint16_t rgb(int r,int g,int b) {
    return static_cast<uint16_t>(((r>>3)<<11)|((g>>2)<<5)|(b>>3));
}
uint16_t pixel(const GFXcanvas16& canvas,int x,int y) {
    return canvas.pixels[y*160+x];
}
void render(GFXcanvas16& canvas,brd_ui::Model& m,uint8_t theme,uint32_t rpm) {
    brd_ui::Curve curve{};
    m.measurement.value=rpm;
    m.measurement.peak_value=rpm;
    brd_ui::style_scene::draw(canvas,theme,brd_ui::Page::Main,4,m,curve);
}
size_t count_color(const GFXcanvas16& canvas,int x0,int y0,int x1,int y1,uint16_t color) {
    size_t count=0;
    for(int y=y0;y<y1;++y)for(int x=x0;x<x1;++x) {
        if(pixel(canvas,x,y)==color)++count;
    }
    return count;
}
size_t torque_filled_segments(const GFXcanvas16& canvas,uint16_t color) {
    size_t count=0;
    for(int i=0;i<16;++i) {
        if(pixel(canvas,61+i*6,68)==color)++count;
    }
    return count;
}
}
int main() {
    static_assert(BRD_UI_INDICATOR_FULL_SCALE_RPM>0UL,
                  "UI indicator full-scale RPM cannot be zero.");
    const uint32_t full_scale=BRD_UI_INDICATOR_FULL_SCALE_RPM;
    const uint32_t half_scale=full_scale/2U;
    const uint32_t over_scale=full_scale+(full_scale/3U)+1U;
    GFXcanvas16 canvas(160,80);
    canvas.setTextWrap(false);
    brd_ui::Model m{};
    m.battery=80U;
    m.connected=true;
    m.measurement.loaded=false;
    const uint16_t nebula_blue=rgb(75,227,228);
    const uint16_t nebula_bg=rgb(4,10,23);
    const uint16_t dial_orange=rgb(250,183,88);
    const uint16_t torque_orange=rgb(250,124,77);

    // [新增] 未裝載、已裝載、LIVE、MAX 均能看到三層底環（包含雙圈）。
    render(canvas,m,0U,0U);
    assert(pixel(canvas,41,72)!=nebula_bg);
    assert(pixel(canvas,41,67)!=nebula_bg);
    assert(pixel(canvas,41,61)!=nebula_bg);
    assert(count_color(canvas,5,5,75,75,nebula_blue)==0U);
    m.measurement.loaded=true;
    render(canvas,m,0U,0U);
    assert(pixel(canvas,41,72)!=nebula_bg);
    assert(pixel(canvas,41,67)!=nebula_bg);
    assert(count_color(canvas,5,5,75,75,nebula_blue)==0U);

    // [新增] 模擬發射後 RPM 指示弧：0 -> 50% -> 100% -> >100%。
    m.measurement.loaded=false;
    render(canvas,m,0U,0U);
    const auto nebula_zero=count_color(canvas,5,5,75,75,nebula_blue);
    render(canvas,m,0U,half_scale);
    const auto nebula_half=count_color(canvas,5,5,75,75,nebula_blue);
    render(canvas,m,0U,full_scale);
    const auto nebula_full=count_color(canvas,5,5,75,75,nebula_blue);
    render(canvas,m,0U,over_scale);
    const auto nebula_over=count_color(canvas,5,5,75,75,nebula_blue);
    assert(nebula_zero==0U && nebula_half>0U);
    assert(nebula_half<nebula_full && nebula_full==nebula_over);

    // [新增] DIAL 橙色刻度弧也以 CFG 轉速滿格。
    render(canvas,m,1U,0U);
    const auto dial_zero=count_color(canvas,0,18,75,80,dial_orange);
    render(canvas,m,1U,half_scale);
    const auto dial_half=count_color(canvas,0,18,75,80,dial_orange);
    render(canvas,m,1U,full_scale);
    const auto dial_full=count_color(canvas,0,18,75,80,dial_orange);
    render(canvas,m,1U,over_scale);
    const auto dial_over=count_color(canvas,0,18,75,80,dial_orange);
    assert(dial_zero<dial_half && dial_half<dial_full && dial_full==dial_over);

    // [新增] TORQUE 的 16 段橘色柱 CFG 100% 全亮；更高仍為 16 段。
    render(canvas,m,2U,0U);
    assert(torque_filled_segments(canvas,torque_orange)==0U);
    render(canvas,m,2U,half_scale);
    assert(torque_filled_segments(canvas,torque_orange)==8U);
    render(canvas,m,2U,full_scale);
    assert(torque_filled_segments(canvas,torque_orange)==16U);
    render(canvas,m,2U,over_scale);
    assert(torque_filled_segments(canvas,torque_orange)==16U);

    std::puts("PASS: all three indicators saturate at configured full scale; NEBULA persistent dark dual-rings");
}
