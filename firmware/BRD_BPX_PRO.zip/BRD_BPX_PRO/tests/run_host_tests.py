#!/usr/bin/env python3
"""[新增] Build and run real firmware modules against host hardware boundaries."""
import os
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parents[1]
BIN = ROOT / "tests" / "bin"
BIN.mkdir(exist_ok=True)
FLAGS = ["g++", "-std=c++17", "-Wall", "-Wextra", "-Werror",
         "-fsanitize=address,undefined", "-fno-omit-frame-pointer",
         "-Itests/stubs", "-I."]
ENV = os.environ.copy()
# LeakSanitizer cannot inspect /proc under some execution tracers.
# AddressSanitizer and UndefinedBehaviorSanitizer remain enabled.
ENV["ASAN_OPTIONS"] = ENV.get("ASAN_OPTIONS", "") + ":detect_leaks=0"
ENV["UBSAN_OPTIONS"] = ENV.get("UBSAN_OPTIONS", "") + ":halt_on_error=1"
CASES = {
    "rpm_adc": ["tests/test_rpm_adc.cpp", "brd_rpm_adc.cpp"],
    "load_adc": ["tests/test_load_adc.cpp", "brd_load_adc.cpp"],
    "adc_shared": ["tests/test_adc_shared.cpp", "brd_adc_shared.cpp"],
    "model": ["tests/test_model.cpp", "brd_settings_model.cpp"],
    "ui_input_curve": ["tests/test_ui_input_curve.cpp", "brd_ui_input.cpp", "brd_ui_curve.cpp"],
    "runtime": ["tests/test_runtime.cpp", "brd_measurement.cpp", "brd_settings.cpp",
                "brd_settings_model.cpp", "brd_bbp_session.cpp", "brd_bbp_protocol.cpp"],
    "ble": ["tests/test_ble.cpp", "brd_settings_ble.cpp", "brd_settings_model.cpp"],
    "auto": ["tests/test_auto_baseline.cpp", "brd_measurement.cpp"],
    "boot": ["tests/render_boot.cpp", "brd_tft.cpp",
             "brd_ui_core.cpp", "brd_ui_screen.cpp", "brd_ui_widgets.cpp",
             "brd_ui_page_main.cpp", "brd_ui_page_ir.cpp", "brd_ui_page_ota.cpp",
             "brd_ui_page_alert.cpp", "brd_ui_page_graph.cpp", "brd_ui_curve.cpp", "brd_ui_input.cpp"],
    "ui_layout": ["tests/test_ui_layout.cpp",
                  "brd_ui_core.cpp", "brd_ui_screen.cpp", "brd_ui_widgets.cpp",
                  "brd_ui_page_main.cpp", "brd_ui_page_ir.cpp", "brd_ui_page_ota.cpp",
                  "brd_ui_page_alert.cpp", "brd_ui_page_graph.cpp", "brd_ui_curve.cpp", "brd_ui_input.cpp"],
    "ui_ir_adc": ["tests/test_ui_ir_adc.cpp",
                 "brd_ui_core.cpp", "brd_ui_screen.cpp", "brd_ui_widgets.cpp",
                 "brd_ui_page_main.cpp", "brd_ui_page_ir.cpp", "brd_ui_page_ota.cpp",
                 "brd_ui_page_alert.cpp", "brd_ui_page_graph.cpp", "brd_ui_curve.cpp", "brd_ui_input.cpp"],
    "ui_dirty": ["tests/test_ui_dirty.cpp",
                 "brd_ui_core.cpp", "brd_ui_screen.cpp", "brd_ui_widgets.cpp",
                 "brd_ui_page_main.cpp", "brd_ui_page_ir.cpp", "brd_ui_page_ota.cpp",
                 "brd_ui_page_alert.cpp", "brd_ui_page_graph.cpp", "brd_ui_curve.cpp", "brd_ui_input.cpp"],
    "ota_protocol": ["tests/test_ota_protocol.cpp", "brd_ota_protocol.cpp"],
    "ota_runtime": ["tests/test_ota_runtime.cpp", "brd_ota.cpp", "brd_ota_protocol.cpp", "brd_settings_model.cpp"],
    "ota_history": ["tests/test_ota_history.cpp", "brd_bbp.cpp", "brd_bbp_session.cpp", "brd_bbp_protocol.cpp"],
}


def run(args):
    subprocess.run(args, cwd=ROOT, env=ENV, check=True)


for name, sources in CASES.items():
    executable = BIN / name
    libraries = ["-lcrypto"] if name == "ota_runtime" else []
    run(FLAGS + sources + libraries + ["-o", str(executable)])
    arguments = [str(executable)]
    if name == "boot":
        arguments.append(str(BIN / "boot.pgm"))
    run(arguments)
    if name == "boot":
        # [V1.2 新增] OTA 專用扇形進度逐階段檢視，其餘驗證/完成畫面維持。
        for frame in ["main", "max", "low", "fault", "ota", "ota0", "ota25", "ota50", "ota75", "ota100", "verify", "done", "irnone", "ir1", "ir2", "irboth", "graph", "waitcharge"]:
            run([str(executable), str(BIN / (frame + ".pgm")), frame])

run(FLAGS + ["-fsyntax-only", "brd_bbp.cpp", "brd_io.cpp", "brd_tft.cpp", "brd_load_adc.cpp", "brd_rpm_adc.cpp", "brd_battery.cpp", "brd_adc_shared.cpp",
             "brd_ui_core.cpp", "brd_ui_screen.cpp", "brd_ui_widgets.cpp",
             "brd_ui_page_main.cpp", "brd_ui_page_ir.cpp", "brd_ui_page_ota.cpp",
             "brd_ui_page_alert.cpp", "brd_ui_page_graph.cpp", "brd_ui_curve.cpp", "brd_ui_input.cpp"])
run(FLAGS + ["-x", "c++", "-fsyntax-only", "examples/Adafruit_ST7735_PanelCheck/Adafruit_ST7735_PanelCheck.ino"])
run(FLAGS + ["-x", "c++", "-fsyntax-only", "BRD_BPX_PRO.ino"])
run(["python3", "tests/test_ir_dxf_geometry.py"])
run(["python3", "tests/test_adafruit_api.py"])
print(f"PASS: {len(CASES)} host executables including GPIO5, curve graph, LOAD ADC, BBP and OTA.")
