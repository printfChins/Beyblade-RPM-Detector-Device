/* [新增] 直接測試 GPIO1 ADC 對應 0.89~2.65V、遲滯、取樣與失效安全。 */
#include <cassert>
#include <cstdio>
#include <Arduino.h>
#include "brd_config.h"
#include "brd_load_adc.h"
#include "brd_adc_shared.h"
uint64_t test_clock_us = 100000U;
static int mv = 2650;
static bool fault = false;
namespace brd_adc {
esp_err_t configure(int, adc_atten_t, adc_bitwidth_t) { return fault ? ESP_ERR_INVALID_STATE : ESP_OK; }
esp_err_t calibrate(int) { return ESP_OK; }
esp_err_t read_mv(int, int &raw, int &out) {
    raw = 1000;
    out = mv;
    return fault ? ESP_ERR_INVALID_RESPONSE : ESP_OK;
}
}
static void sample_at(int value, unsigned ms) {
    mv = value;
    test_clock_us += ms * 1000ULL;
    brd_load_adc_update();
}
int main() {
    brd_load_adc_begin();
    brd_load_adc_update();
    assert(brd_load_adc_valid() && !brd_load_adc_active() && brd_load_adc_voltage_mv() == 2650U);
    sample_at(890, 20);
    assert(brd_load_adc_active());
    sample_at(1775, 20);
    assert(brd_load_adc_active());
    sample_at(1949, 20);
    assert(brd_load_adc_active());
    sample_at(1950, 20);
    assert(!brd_load_adc_active());
    sample_at(1601, 20);
    assert(!brd_load_adc_active());
    sample_at(1600, 20);
    assert(brd_load_adc_active());
    fault = true;
    sample_at(890, 20);
    assert(brd_load_adc_active());
    sample_at(890, LOAD_ADC_STALE_TIMEOUT_MS + 20);
    assert(!brd_load_adc_valid() && !brd_load_adc_active());
    fault = false;
    sample_at(890, 20);
    assert(brd_load_adc_valid() && brd_load_adc_active());
    puts("PASS: ADC LOAD hysteresis, sample period, stale fail-safe.");
}
